"""Hook the three photo rooms of the eleventh batch (IndevT11.bb + generated IndevT11Data.bb) into the game.
Run gen_b11.py --game first (it writes b11_names.txt and b11_rooms.ini.txt). Safe to run twice.
Originals are kept once as *.bak_t11."""
import os
import shutil
from make_docs11 import TITLES

ROOT = r"I:\MythicalC v1.2.7\v0.1\scpcb-dx9\scpcb-dx9"


def load(rel):
    raw = open(os.path.join(ROOT, rel), 'rb').read()
    nl = b'\r\n' if b'\r\n' in raw else b'\n'
    return raw.decode('latin-1'), nl.decode()


def after_line(text, anchor, block, marker, nl):
    if marker in text:
        return text, False
    i = text.index(anchor)
    j = text.index(nl, i) + len(nl)
    return text[:j] + block.replace('\n', nl) + text[j:], True


def before_line(text, anchor, block, marker, nl):
    if marker in text:
        return text, False
    i = text.index(anchor)
    j = text.rfind(nl, 0, i) + len(nl)
    return text[:j] + block.replace('\n', nl) + text[j:], True


def save(rel, text):
    p = os.path.join(ROOT, rel)
    bak = p + '.bak_t11'
    if not os.path.exists(bak):
        shutil.copy2(p, bak)
    open(p, 'wb').write(text.encode('latin-1'))


NAMES = [l.strip() for l in open('b11_names.txt') if l.strip()]
ALIASES = [('room2hoistoffice', ('hoist', 'hoistoffice')), ('room2shutterhall', ('shutter', 'shutterhall')),
           ('room2machinecorr', ('machine', 'machinecorr'))]

if __name__ == '__main__':
    done = []
    t, nl = load('Main.bb')
    t, c = after_line(t, 'Include "IndevT10Data.bb"', 'Include "IndevT11.bb"\nInclude "IndevT11Data.bb"\n', 'Include "IndevT11.bb"', nl)
    done.append(('Main include', c))
    t, c = after_line(t, 'IndevT10Events()', '\tIndevT11Events() ;Indev: the three photo rooms of the eleventh batch (IndevT11.bb)\n', 'IndevT11Events()', nl)
    done.append(('Main events', c))
    al = ''
    for room, keys in ALIASES:
        al += '\t\t\t\t\t\t\tCase %s\n\t\t\t\t\t\t\t\troomName = "%s"\n' % (', '.join('"%s"' % k for k in keys), room)
    t, c = before_line(t, 'Case "blockhall", "blockd"', al, 'roomName = "room2hoistoffice"', nl)
    done.append(('Main teleport aliases', c))
    save('Main.bb', t)

    t, nl = load('MapSystem.bb')
    fr = '\t\tCase %s\n\t\t\t;[Block]\n\t\t\tIndevFillT11(r) ;Indev: eleventh-batch rooms, table in IndevT11Data.bb\n\t\t\t;[End Block]\n' % ', '.join('"%s"' % n for n in NAMES)
    t, c = before_line(t, 'Case "room2blockhall"', fr, 'IndevFillT11(r)', nl)
    done.append(('MapSystem FillRoom', c))
    save('MapSystem.bb', t)

    t, nl = load('UpdateEvents.bb')
    ue = '\t\t\tCase "t11room"\n\t\t\t\t;[Block]\n\t\t\t\tUpdateIndevT11(e) ;Indev (IndevT11.bb)\n\t\t\t\t;[End Block]\n'
    t, c = before_line(t, 'Case "v02room"', ue, 'UpdateIndevT11(e)', nl)
    done.append(('UpdateEvents', c))
    save('UpdateEvents.bb', t)

    t, nl = load(r'Data\rooms.ini')
    if '[room2hoistoffice]' not in t:
        add = open('b11_rooms.ini.txt').read()
        t = t.rstrip('\r\n') + nl + add.replace('\n', nl)
        done.append(('rooms.ini', True))
    save(r'Data\rooms.ini', t)

    t, nl = load(r'Data\items.ini')
    if '[docho1b]' not in t:
        add = ''
        for n in sorted(TITLES):
            handwritten = n[-1] == 'b'
            add += ('\n[%s]\ngroup = paper\nmodel = GFX\\items\\paper.x\ninvicon = GFX\\items\\%s\ndocument = GFX\\items\\%s.jpg\nscale = 0.003\n%ssound = 0\n'
                    % (n, 'INVnote.png' if handwritten else 'INVpaper.png', n, 'texture override = GFX\\items\\notetexture.jpg\n' if handwritten else ''))
        t = t.rstrip('\r\n') + nl + add.replace('\n', nl)
        done.append(('items.ini', True))
    save(r'Data\items.ini', t)

    t, nl = load(r'Data\strings.ini')
    names = ''.join('%s = %s\n' % (k, TITLES[k]) for k in sorted(TITLES))
    t, c = after_line(t, 'docres1b = ', names, 'docho1b = ', nl)
    done.append(('strings.ini', c))
    save(r'Data\strings.ini', t)

    for d in done:
        print(d)
